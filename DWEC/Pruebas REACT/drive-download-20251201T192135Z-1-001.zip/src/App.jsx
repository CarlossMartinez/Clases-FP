import "./App.css"
import "./css/styles.css"

import { useState, useEffect } from "react"

import Top from "./components/Top.jsx"
import Header from "./components/Header.jsx"
import Loading from "./components/Loading.jsx"
import Main from "./components/Main.jsx"
import Footer from "./components/Footer.jsx"

import {getProducts} from "./services/importProducts.js"

export default function App(){
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        localStorage.getItem("articles-data")?
        setProducts(JSON.parse(localStorage.getItem("articles-data"))):
        getProducts(setProducts, setLoading);
    }, []);

    function deleteArticle(id){
        setProducts(products.filter(product => product.id != id));
    }

    return(
      <div id="page">
        <Top/>
        <Header/>
        {loading?<Loading/>:<Main products={products} deleteArticle={deleteArticle}/>}
        <Footer/>
      </div>
    )
}